import json
import os
import requests
import traceback

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN")

def lambda_handler(event, context):
    # Log full event for debugging
    try:
        print("🔍 Full event:")
        print(json.dumps(event, indent=2))
    except Exception as e:
        print("⚠️ Failed to serialize event:", str(e))
        print("Raw event fallback:", event)

    method = event.get("httpMethod", "GET")

    # CORS headers
    cors_headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Authorization,Content-Type,X-Amz-Date,X-Api-Key,X-Amz-Security-Token,X-Requested-With,Accept,User-Agent",
    }

    if method == "OPTIONS":
        return {
            'statusCode': 200,
            'headers': cors_headers,
            'body': json.dumps({'message': 'CORS preflight success'})
        }

    # Try to get the URL from either the proxy path or query param
    proxy_path = (event.get("pathParameters") or {}).get("proxy", "")
    query_params = event.get("queryStringParameters") or {}
    url = f"https://{proxy_path}" if proxy_path else query_params.get("url")

    if not url:
        return {
            'statusCode': 400,
            'headers': {**cors_headers, 'Content-Type': 'application/json'},
            'body': json.dumps({'error': 'Missing "url" query parameter or proxy path'})
        }

    # Prepare header
    if "raw.githubusercontent.com" in url and GITHUB_TOKEN:
        headers = {
            'Authorization': f'token {GITHUB_TOKEN}',
            'Accept': 'application/vnd.github.v3.raw'
        }
    else:
        incoming_headers = event.get("headers") or {}
        headers = {
            k: v for k, v in incoming_headers.items()
            if k.lower().startswith("x-")
            or k.lower() in ["authorization", "content-type", "user-agent", "accept"]
        }

    try:
        # Perform request
        if method == "GET":
            response = requests.get(url, headers=headers)
        elif method == "POST":
            body = event.get("body", "")
            response = requests.post(url, headers=headers, data=body)
        elif method == "DELETE":
            response = requests.delete(url, headers=headers)
        else:
            return {
                'statusCode': 405,
                'headers': cors_headers,
                'body': json.dumps({'error': f'Method {method} not allowed'})
            }

        response.raise_for_status()
        content_type = response.headers.get('Content-Type', 'text/plain')

        return {
            'statusCode': response.status_code,
            'headers': {**cors_headers, 'Content-Type': content_type},
            'body': response.text
        }

    except Exception as e:
        print("❌ Exception occurred:")
        print(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': {**cors_headers, 'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }


import json
import os
import requests

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN")

def lambda_handler(event, context):
    print("Event received:")
    print(json.dumps(event))  # ✅ Helps debug in CloudWatch
    
    try:
        params = event.get('queryStringParameters') or {}
        url = params.get('url')
        
        if not url:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                    "Access-Control-Allow-Headers": "*"
                },
                'body': json.dumps({'error': 'Missing "url" query parameter'})
            }

        headers = {
            'Authorization': f'token {GITHUB_TOKEN}',
            'Accept': 'application/vnd.github.v3.raw'
        }

        response = requests.get(url, headers=headers)
        response.raise_for_status()

        content_type = response.headers.get('Content-Type', 'application/json')

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': content_type,
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "*"
            },
            'body': response.text
        }

    except Exception as e:
        # Catch all unexpected errors
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "*"
            },
            'body': json.dumps({'error': str(e)})
        }


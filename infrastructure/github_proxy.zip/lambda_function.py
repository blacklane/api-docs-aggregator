import json
import os
import requests
import traceback

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN")

def lambda_handler(event, context):
    print("Event received:")
    print(json.dumps(event))  # ✅ Helps debug in CloudWatch

    method = event.get("httpMethod", "GET")
    
    # Common headers
    cors_headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "*"
    }

    # OPTIONS preflight request
    if method == "OPTIONS":
        return {
            'statusCode': 200,
            'headers': cors_headers,
            'body': json.dumps({'message': 'CORS preflight success'})
        }

    # Safely extract URL
    url = None
    if "queryStringParameters" in event and event["queryStringParameters"]:
        url = event["queryStringParameters"].get("url")

    if not url:
        return {
            'statusCode': 400,
            'headers': {**cors_headers, 'Content-Type': 'application/json'},
            'body': json.dumps({'error': 'Missing "url" query parameter'})
        }

    headers = {
        'Authorization': f'token {GITHUB_TOKEN}',
        'Accept': 'application/vnd.github.v3.raw'
    }

    try:
        if method == "GET":
            response = requests.get(url, headers=headers)
        elif method == "POST":
            body = event.get("body", "")
            response = requests.post(url, headers=headers, data=body)
        elif method == "DELETE":
            response = requests.delete(url, headers=headers)
        else:
            return {
                'statusCode': 405,
                'headers': cors_headers,
                'body': json.dumps({'error': f'Method {method} not allowed'})
            }

        response.raise_for_status()
        content_type = response.headers.get('Content-Type', 'text/plain')

        return {
            'statusCode': response.status_code,
            'headers': {**cors_headers, 'Content-Type': content_type},
            'body': response.text
        }

    except Exception as e:
        print(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': {**cors_headers, 'Content-Type': 'application/json'},
            'body': json.dumps({'error': str(e)})
        }


